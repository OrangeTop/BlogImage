function doSubmit(){
	var userName = document.getElementById("userName").value;
	if(0==userName.length){
		alert("账号不能为空!");
		return false;
	}
	
}